package Ocsinventory::Agent::Backend::OS::Linux::Distro::NonLSB;

$runMeIfTheseChecksFailed = ["Ocsinventory::Agent::Backend::OS::Linux::Distro::LSB"];

1;
